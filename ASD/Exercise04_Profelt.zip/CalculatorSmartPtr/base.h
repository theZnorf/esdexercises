//       $Id: base.h 3024 2006-12-06 20:59:07Z kulczyck $
//      $URL: file:///C:/Documents%20and%20Settings/kulczyck/Desktop/Desktop/SVN-Repository/Hochschule/Lehre/FH/BIN/SWE3/Programme/Scanner-II/trunk/src/base.h $
// $Revision: 3024 $
//     $Date: 2006-12-06 21:59:07 +0100 (Mi, 06 Dez 2006) $
//   Creator: peter.kulczycki<AT>fh-hagenberg.at
//   $Author: kulczyck $

#if !defined BASE_SCANNER_II_H
#define      BASE_SCANNER_II_H

#include <iosfwd>
#include <string>

class scanner;
class scanner_impl;
class symbol;

#endif   // BASE_SCANNER_II_H
