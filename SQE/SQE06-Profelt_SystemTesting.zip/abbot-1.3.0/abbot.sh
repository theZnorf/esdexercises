#! /bin/bash

CP="lib/costello.jar"

java -jar $CP $1 $2 $3 $4 $5
